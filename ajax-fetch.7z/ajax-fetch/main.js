function loadFradment(file){
   //1. create comm object
let xhr = new XMLHttpRequest()          

   //2. configure connection
   xhr.open("GET", `partials/${file}.html`)

   //3) send the request
   xhr.onload = function(){
       document.querySelector('.dynamic').innerHTML = xhr.responseText
   }
   xhr.send()
  
}